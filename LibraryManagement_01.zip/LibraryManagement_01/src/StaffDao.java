import java.sql.*;
public class StaffDao {

	
	public static int save(String Name,String Password,String Email,String Address,String Dpt,String Contact_no){
		int status=0;
		try{
			Connection con=DB.getConnection();
			PreparedStatement ps=con.prepareStatement("insert into Staff(Name,Password,Email,Address,Dpt,Contact_no) values(?,?,?,?,?,?)");
			ps.setString(1,Name);
			ps.setString(2,Password);
			ps.setString(3,Email);
			ps.setString(4,Address);
			ps.setString(5,Dpt);
			ps.setString(6,Contact_no);
			status=ps.executeUpdate();
			con.close();
		}catch(Exception e){System.out.println(e);}
		return status;
	}
	public static int delete(int id){
		int status=0;
		try{
			Connection con=DB.getConnection();
			PreparedStatement ps=con.prepareStatement("delete from Staff where ID=?");
			ps.setInt(1,id);
			status=ps.executeUpdate();
			con.close();
		}catch(Exception e){System.out.println(e);}
		return status;
	}

	public static boolean validate(String name,String password){
		boolean status=false;
		try{
			Connection con=DB.getConnection();
			PreparedStatement ps=con.prepareStatement("select * from Staff where Name=? and Password=?");
			ps.setString(1,name);
			ps.setString(2,password);
			ResultSet rs=ps.executeQuery();
			status=rs.next();
			con.close();
		}catch(Exception e){System.out.println(e);}
		return status;
	}

}
