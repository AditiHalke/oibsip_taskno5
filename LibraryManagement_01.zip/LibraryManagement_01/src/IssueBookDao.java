import java.sql.*;
public class IssueBookDao {
	
public static boolean checkBook(String bookcallno){
	boolean status=false;
	try{
		Connection con=DB.getConnection();
		PreparedStatement ps=con.prepareStatement("select * from books where callno=?");
		ps.setString(1,bookcallno);
	    ResultSet rs=ps.executeQuery();
		status=rs.next();
		con.close();
	}catch(Exception e){System.out.println(e);}
	return status;
}

public static int save(String bookcallno,int User_id,String UserName,String UserContact){
	int status=0;
	try{
		Connection con=DB.getConnection();
		
		status=updatebook(bookcallno);//updating quantity and issue
		
		if(status>0){
		PreparedStatement ps=con.prepareStatement("insert into IssueBook(bookcallno,User_id,UserName,UserContact) values(?,?,?,?)");
		ps.setString(1,bookcallno);
		ps.setInt(2,User_id);
		ps.setString(3,UserName);
		ps.setString(4,UserContact);
		status=ps.executeUpdate();
		}
		
		con.close();
	}catch(Exception e){System.out.println(e);}
	return status;
}
public static int updatebook(String bookcallno){
	int status=0;
	int Quantity=0,Issued=0;
	try{
		Connection con=DB.getConnection();
		
		PreparedStatement ps=con.prepareStatement("select Quantity,Issued from Books where Callno=?");
		ps.setString(1,bookcallno);
		ResultSet rs=ps.executeQuery();
		if(rs.next()){
			Quantity=rs.getInt("Quantity");
			Issued=rs.getInt("Issued");
		}
		
		if(Quantity>0){
		PreparedStatement ps2=con.prepareStatement("update books set Quantity=?,Issued=? where Callno=?");
		ps2.setInt(1,Quantity-1);
		ps2.setInt(2,Issued+1);
		ps2.setString(3,bookcallno);
		
		status=ps2.executeUpdate();
		}
		con.close();
	}catch(Exception e){System.out.println(e);}
	return status;
}
}
