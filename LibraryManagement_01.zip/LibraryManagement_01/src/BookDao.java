import java.sql.Connection;
import java.sql.PreparedStatement;

public class BookDao {
public static int save(String Callno,String Name,String Author,String Publisher,int Quantity){
	int status=0;
	try{
		Connection con=DB.getConnection();
		PreparedStatement ps=con.prepareStatement("insert into Books(Callno,Name,Author,Publisher,Quantity) values(?,?,?,?,?)");
		ps.setString(1,Callno);
		ps.setString(2,Name);
		ps.setString(3,Author);
		ps.setString(4,Publisher);
		ps.setInt(5,Quantity);
		status=ps.executeUpdate();
		con.close();
	}catch(Exception e){System.out.println(e);}
	return status;
}
}