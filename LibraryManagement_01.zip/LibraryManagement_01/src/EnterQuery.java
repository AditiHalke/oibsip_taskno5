import javax.swing.*;
import java.awt.event.*;

public class EnterQuery extends JFrame {
    private JTextField queryField;
    
    public EnterQuery() {
        initComponents();
    }
    
    private void initComponents() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        queryField = new JTextField(20);
        queryField.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                // This block of code executes when the "Enter" key is pressed
                String query = queryField.getText();
                // Process the query here (e.g., perform a search, execute a query, etc.)
                System.out.println("Entered query: " + query);
                // For demonstration, printing the query to the console
            }
        });
        
        getContentPane().add(queryField);
        
        pack();
        setLocationRelativeTo(null);
    }
    
    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new EnterQuery().setVisible(true);
            }
        });
    }
}
